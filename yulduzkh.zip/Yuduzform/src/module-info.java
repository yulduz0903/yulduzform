module Yuduzform {
	requires java.desktop;
	
}